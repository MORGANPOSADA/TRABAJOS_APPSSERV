package server;

public class Methods {

    public double addition(double num1, double num2){       //el metodo suma
        return (num1 + num2);                                  //me retornara el num1 mas el num2 bro
    }

    /*public String imc(String name, double height, double weight){
        double imc = (weight / (height * height));
        return "Nombre: "
    }*/
}

